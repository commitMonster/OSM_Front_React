import React from 'react';
import { Route ,Router} from 'react-router-dom';
import MainLayout from './commons/MainLayout'
import DashboardLayout from  './commons/DashboardLayout';

import AdminBannerContainer from './containers/AdminBannerContainer'
import AdminMainContainer from './containers/AdminMainContainer'
import AdminProductContainer from './containers/AdminProductContainer'
const AdminRoute = () => {
    return (
    <>
            <DashboardLayout >
            <Route path="/admin" exact component={AdminMainContainer} />
            <Route path="/admin/Product"  component={AdminBannerContainer}/>
            <Route path="/admin/Banner" component={AdminProductContainer}/>
            </DashboardLayout>
        
    </>
    )
};

export default AdminRoute;

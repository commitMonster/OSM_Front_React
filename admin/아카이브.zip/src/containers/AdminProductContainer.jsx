import React from 'react';
import AdminProduct from '../components/admin/AdminProduct'

const AdminProductContainer = (props) => {
    return (<><AdminProduct /></>)
};
export default AdminProductContainer;
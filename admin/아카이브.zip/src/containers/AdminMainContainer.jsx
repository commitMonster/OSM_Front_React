import React from 'react';
import AdminDashboard from '../components/admin/AdminDashboard'
const AdminMainContainer = (props) => {
    return(<><AdminDashboard /></>)
};

export default AdminMainContainer;
import React from 'react';
import AdminBanner from '../components/admin/AdminBanner'

const AdminBannerContainer = (props) => {
    return (<AdminBanner />);
}
export default AdminBannerContainer;
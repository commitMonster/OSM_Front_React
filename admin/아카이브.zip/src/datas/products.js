import { Description } from '@material-ui/icons';
import { v4 as uuid } from 'uuid';

export default [
  {
    media:'',
    title:'',
    description:'',
    totalDownloads:'',
    title:''
  },{
    media:'',
    title:'',
    description:'',
    totalDownloads:'',
    title:''
  },{
    media:'',
    title:'',
    description:'',
    totalDownloads:'',
    title:''
  },{
    media:'',
    title:'',
    description:'',
    totalDownloads:'',
    title:''
  },{
    media:'',
    title:'',
    description:'',
    totalDownloads:'',
    title:''
  },
   
];
